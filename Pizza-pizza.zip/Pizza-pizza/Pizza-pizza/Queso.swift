//
//  Queso.swift
//  Pizza-pizza
//
//  Created by Rodrigo Jara on 7/25/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import UIKit

class Queso: UIViewController {

    var queso : String = "MOZARELA"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func queso1(sender: UIButton) {
        queso = "MOZARELA"
    }

    @IBAction func queso2(sender: UIButton) {
        queso = "CHEDDAR"
    }
    
    @IBAction func queso3(sender: UIButton) {
        queso = "PARMESANO"
    }
    
    @IBAction func queso4(sender: UIButton) {
        queso = "SIN QUESO"
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
