//
//  MedioDePago.swift
//  Pizza-pizza
//
//  Created by Rodrigo Jara on 7/25/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import UIKit

class MedioDePago: UIViewController {

    var pago : String = "EFECTIVO"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func efectivo(sender: UIButton) {
        pago = "EFECTIVO"
    }

    @IBAction func local(sender: UIButton) {
        pago = "TARJETA"
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        /*
        let vista1 = segue.destinationViewController as! ViewController
        let vista2 = segue.destinationViewController as! Masa
        let vista3 = segue.destinationViewController as! Queso
        let vista4 = segue.destinationViewController as! Ingredientes
        let vista5 = segue.destinationViewController as! Despacho
        let vista6 = segue.destinationViewController as! MedioDePago*/
        let pedido = segue.destinationViewController as! Orden
        
        /*
        pedido.valor1 = vista1.tam
        pedido.valor2 = vista2.masa
        pedido.valor3 = vista3.queso
        pedido.valor4 = String(vista4.total)
        pedido.valor5 = vista5.despacho*/
        pedido.valor6 = pago
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
