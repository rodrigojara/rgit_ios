// Desarrollado por Rodrigo Jara - Santiago, Chile

import UIKit

enum Velocidades : Int{
    case apagado = 0
    case velocidadBaja = 20
    case velocidadMedia = 50
    case velocidadAlta = 120
    
    init (velocidadInicial : Velocidades){
        self = .apagado
        self = .velocidadBaja
        self = .velocidadMedia
        self = .velocidadAlta
    }
}

class Auto{
    var velocidad : Velocidades
    
    init(){
        velocidad = Velocidades.apagado
    }
    
    func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena: String){
        if (velocidad.rawValue == 0){
            velocidad = .velocidadBaja
            return (0, "Apagado")
        }else if (velocidad.rawValue == 20){
            velocidad = .velocidadMedia
            return (velocidad.rawValue, "Velocidad Baja")
        }else if (velocidad.rawValue == 50){
            velocidad = .velocidadAlta
            return (velocidad.rawValue, "Velocidad Media")
        }else{
            velocidad = .velocidadMedia
            return (velocidad.rawValue, "Velocidad Alta")
        }
    }
}

var auto = Auto()

for i in 0...19{
    var autito = auto.cambioDeVelocidad()
    print (autito)
}



