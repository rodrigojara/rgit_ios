//
//  Colores.swift
//  Hamburguesas
//
//  Created by Rodrigo Jara on 7/3/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import Foundation
import UIKit

struct Colores{
    let colores = [
        UIColor(red: 210/255.0 , green: 40/255.0 , blue: 200/255.0 , alpha: 1 ),
        UIColor(red: 210/255.0 , green: 100/255.0 , blue: 200/255.0 , alpha: 1 ),
        UIColor(red: 2/255.0 , green: 1/255.0 , blue: 200/255.0 , alpha: 1 ),
        UIColor(red: 210/255.0 , green: 255/255.0 , blue: 50/255.0 , alpha: 1 ),
        UIColor(red: 2/255.0 , green: 25/255.0 , blue: 155/255.0 , alpha: 1 ),
        UIColor(red: 24/255.0 , green: 100/255.0 , blue: 150/255.0 , alpha: 1 ),
        UIColor(red: 20/255.0 , green: 123/255.0 , blue: 250/255.0 , alpha: 1 ),
        UIColor(red: 1/255.0 , green: 170/255.0 , blue: 140/255.0 , alpha: 1 ),
        UIColor(red: 10/255.0 , green: 25/255.0 , blue: 100/255.0 , alpha: 1 )]
    
    func regresaColor() -> UIColor{
        return colores[Int(arc4random()) % colores.count]
    }
}