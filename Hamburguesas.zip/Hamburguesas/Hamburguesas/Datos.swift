//
//  Datos.swift
//  Hamburguesas
//
//  Created by Rodrigo Jara on 7/3/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import Foundation

class ColeccionDePaises{
    
    let paises = ["Afganistán", "Albania", "Alemania" ,"Andorra","Angola","Antigua y Barbuda","Arabia Saudita","Argelia","Argentina","Armenia","Australia","Austria","Azerbaiyán","Bahamas","Bangladés","Barbados","Baréin","Bélgica","Belice","Benín","Bielorrusia","Birmania","Bolivia","Bosnia y Herzegovina","Botsuana","Brasil","Brunéi","Bulgaria","Burkina Faso","Burundi","Bután","Cabo Verde","Camboya","Camerún","Canadá","Catar","Chad","Chile"]
    
    func obtenPais( )->String{
        return paises[Int(arc4random()) % paises.count]
    }
}

class ColeccionDeHamburguesa{
    
    let hamburguesas = ["Hamburgesa Nº1","Hamburgesa Nº2","Hamburgesa Nº3","Hamburgesa Nº4","Hamburgesa Nº5","Hamburgesa Nº6","Hamburgesa Nº7","Hamburgesa Nº8","Hamburgesa Nº9","Hamburgesa Nº10","Hamburgesa Nº11","Hamburgesa Nº12","Hamburgesa Nº13","Hamburgesa Nº14","Hamburgesa Nº15","Hamburgesa Nº16","Hamburgesa Nº17","Hamburgesa Nº18","Hamburgesa Nº19","Hamburgesa Nº20"]
    
    func obtenHamburguesa( )->String{
        return hamburguesas[Int(arc4random()) % hamburguesas.count]
    }
}