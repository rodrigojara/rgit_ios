//
//  Resumen.swift
//  MiPizza
//
//  Created by Rodrigo Jara on 7/31/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import UIKit

class Resumen: UIViewController {

    
    @IBOutlet weak var tamaño: UILabel!
    @IBOutlet weak var masa: UILabel!
    @IBOutlet weak var queso: UILabel!
    @IBOutlet weak var ingredientes: UILabel!
    @IBOutlet weak var despacho: UILabel!
    @IBOutlet weak var pago: UILabel!
    
    var orden = ["","","","","",""]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool){
        tamaño.text = String(orden[0])
        masa.text = String(orden[1])
        queso.text = String(orden[2])
        ingredientes.text = String(orden[3])
        despacho.text = String(orden[4])
        pago.text = String(orden[5])
    }

}
