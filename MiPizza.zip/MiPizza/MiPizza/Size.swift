//
//  Size.swift
//  MiPizza
//
//  Created by Rodrigo Jara on 7/31/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import UIKit

class Size: UIViewController {
    
    var tam = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func tam1(sender: AnyObject) {
        tam = "CHICA"
    }
    
    @IBAction func tam2(sender: UIButton) {
        tam = "MEDIANA"
    }

    @IBAction func tam3(sender: UIButton) {
        tam = "GRANDE"
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let pedido = segue.destinationViewController as! Masa
        pedido.orden[0] = tam
    }
    
}
