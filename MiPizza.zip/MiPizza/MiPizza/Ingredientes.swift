//
//  Ingredientes.swift
//  MiPizza
//
//  Created by Rodrigo Jara on 7/31/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import UIKit

class Ingredientes: UIViewController {
    
    var orden = ["","","","","",""]
    @IBOutlet weak var total: UITextField!
    var ingredientes = [0,0,0,0,0,0]
    var eleccion = ["","","","","",""]
    var suma = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func contar(num : Int){
        
        if (ingredientes[num] == 0){
            ingredientes[num] = 1
            
            switch num {
            case 0: eleccion[num] = "CHAMPIÑON"
            case 1: eleccion[num] = "ALCACHOFA"
            case 2: eleccion[num] = "POLLO"
            case 3: eleccion[num] = "PIMIENTO"
            case 4: eleccion[num] = "CHOCLO"
            case 5: eleccion[num] = "TOMATE"
            default:
                print ("VALOR NO VÁLIDO")
            }
            
        }else{
            ingredientes[num] = 0
            
            switch num {
            case 0: eleccion[num] = ""
            case 1: eleccion[num] = ""
            case 2: eleccion[num] = ""
            case 3: eleccion[num] = ""
            case 4: eleccion[num] = ""
            case 5: eleccion[num] = ""
            default:
                print ("VALOR NO VÁLIDO")
            }
        }
        
        suma = 0
        for i in 0...5{
            suma = suma + ingredientes[i]
            if suma < 6 && suma >= 1 {
                total.text = String(eleccion)
            }else{
                total.text = String("Min: 1 , Max: 5")
            }
        }
        
    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        
        if suma < 6 && suma >= 1 {
            return true
        }else{
            total.text = String("Min: 1 , Max: 5")
            return false
        }
    }
    
    @IBAction func boton0(sender: UIButton) {
        contar(0)
    }
    @IBAction func boton1(sender: UIButton) {
        contar(1)
    }
    @IBAction func boton2(sender: UIButton) {
        contar(2)
    }
    @IBAction func boton3(sender: UIButton) {
        contar(3)
    }
    @IBAction func boton4(sender: UIButton) {
        contar(4)
    }
    @IBAction func boton5(sender: UIButton) {
        contar(5)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let pedido = segue.destinationViewController as! Despacho
        pedido.orden[0] = self.orden[0]
        pedido.orden[1] = self.orden[1]
        pedido.orden[2] = self.orden[2]
        pedido.orden[3] = String(eleccion)
    }

}
