//
//  Despacho.swift
//  MiPizza
//
//  Created by Rodrigo Jara on 7/31/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import UIKit

class Despacho: UIViewController {
    
    var orden = ["","","","","",""]
    
    var despacho = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func domicilio(sender: UIButton) {
        despacho = "DOMICILIO"
    }

    @IBAction func local(sender: UIButton) {
        despacho = "LOCAL"
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let pedido = segue.destinationViewController as! Pago
        pedido.orden[0] = self.orden[0]
        pedido.orden[1] = self.orden[1]
        pedido.orden[2] = self.orden[2]
        pedido.orden[3] = self.orden[3]
        pedido.orden[4] = despacho
    }
    
}
