//
//  Queso.swift
//  MiPizza
//
//  Created by Rodrigo Jara on 7/31/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import UIKit

class Queso: UIViewController {
    
    var orden = ["","","","","",""]
    
    var queso : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func mozarela(sender: UIButton) {
        queso = "MOZARELA"
    }
    
    @IBAction func cheddar(sender: UIButton) {
        queso = "CHEDDAR"
    }
    
    @IBAction func parmesano(sender: UIButton) {
        queso = "PARMESANO"
    }
    
    @IBAction func sinQueso(sender: UIButton) {
        queso = "SIN QUESO"
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let pedido = segue.destinationViewController as! Ingredientes
        pedido.orden[0] = self.orden[0]
        pedido.orden[1] = self.orden[1]
        pedido.orden[2] = queso
    }
    
}
