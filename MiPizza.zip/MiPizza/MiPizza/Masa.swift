//
//  Masa.swift
//  MiPizza
//
//  Created by Rodrigo Jara on 7/31/16.
//  Copyright © 2016 Rodrigo Jara. All rights reserved.
//

import UIKit

class Masa: UIViewController {
    
    var orden = ["","","","","",""]
    
    var masa : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func delgada(sender: UIButton) {
        masa = "DELGADA"
    }
    
    @IBAction func crujiente(sender: UIButton) {
        masa = "CRUJIENTE"
    }
    
    @IBAction func gruesa(sender: UIButton) {
        masa = "GRUESA"
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let pedido = segue.destinationViewController as! Queso
        pedido.orden[0] = self.orden[0]
        pedido.orden[1] = masa
    }
    
}
